-- Source table we want to monitor (a simplified shipment booking table)
CREATE TABLE IF NOT EXISTS bookings (
    booking_id      SERIAL PRIMARY KEY,
    customer_code   TEXT,
    origin          TEXT,
    destination     TEXT,
    container_count INT,
    rate_usd        NUMERIC(12, 2),
    ship_date       DATE,
    status          TEXT,
    updated_at      TIMESTAMPTZ DEFAULT now()
);

-- Change log populated by a trigger: a lightweight, dependency-free form of CDC
CREATE TABLE IF NOT EXISTS change_log (
    change_id   BIGSERIAL PRIMARY KEY,
    table_name  TEXT        NOT NULL,
    operation   TEXT        NOT NULL,       -- INSERT / UPDATE / DELETE
    row_data    JSONB       NOT NULL,
    changed_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE OR REPLACE FUNCTION capture_change() RETURNS trigger AS $$
BEGIN
    INSERT INTO change_log (table_name, operation, row_data)
    VALUES (TG_TABLE_NAME, TG_OP,
            CASE WHEN TG_OP = 'DELETE' THEN to_jsonb(OLD) ELSE to_jsonb(NEW) END);
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS bookings_cdc ON bookings;
CREATE TRIGGER bookings_cdc
AFTER INSERT OR UPDATE OR DELETE ON bookings
FOR EACH ROW EXECUTE FUNCTION capture_change();

-- Monitor state and results
CREATE TABLE IF NOT EXISTS dq_checkpoint (
    consumer        TEXT PRIMARY KEY,
    last_change_id  BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS dq_violation (
    id          BIGSERIAL PRIMARY KEY,
    change_id   BIGINT      NOT NULL,
    table_name  TEXT        NOT NULL,
    record_key  TEXT,
    rule_name   TEXT        NOT NULL,
    severity    TEXT        NOT NULL,
    message     TEXT        NOT NULL,
    detected_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS dq_run (
    id               BIGSERIAL PRIMARY KEY,
    changes_checked  INT NOT NULL,
    violations_found INT NOT NULL,
    ran_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);
