from datetime import date
from pathlib import Path

import pytest

from dq_monitor.rules import check_max_age_days, evaluate, load_rules

RULES = load_rules(Path(__file__).parent.parent / "rules.yml")["bookings"]["rules"]

GOOD = {
    "booking_id": 1, "customer_code": "ACME", "origin": "INBLR", "destination": "NLRTM",
    "container_count": 4, "rate_usd": 1800.0, "ship_date": "2026-05-01", "status": "CONFIRMED",
}


def names(row):
    return {v.rule_name for v in evaluate(row, RULES)}


def test_clean_row_has_no_violations():
    assert names(GOOD) == set()


@pytest.mark.parametrize("field,value,expected", [
    ("customer_code", None, "customer_required"),
    ("customer_code", "  ", "customer_required"),
    ("origin", "Bangalore", "valid_locode_origin"),
    ("container_count", 0, "container_count_range"),
    ("container_count", 9999, "container_count_range"),
    ("rate_usd", -5, "rate_positive"),
    ("rate_usd", "abc", "rate_positive"),
    ("status", "shipped", "known_status"),
])
def test_bad_values_are_flagged(field, value, expected):
    assert names({**GOOD, field: value}) == {expected}


def test_null_numeric_is_left_to_not_null_rule():
    assert names({**GOOD, "container_count": None}) == set()


def test_date_order():
    rule = [{"name": "order", "type": "date_order", "start": "a", "end": "b"}]
    assert evaluate({"a": "2026-05-02", "b": "2026-05-01"}, rule)
    assert not evaluate({"a": "2026-05-01", "b": "2026-05-02"}, rule)


def test_max_age_days():
    rule = {"column": "d", "days": 30}
    assert check_max_age_days({"d": "2026-01-01"}, rule, today=date(2026, 3, 1))
    assert not check_max_age_days({"d": "2026-02-20"}, rule, today=date(2026, 3, 1))


def test_unknown_rule_type_raises():
    with pytest.raises(ValueError):
        evaluate(GOOD, [{"name": "x", "type": "nope"}])
