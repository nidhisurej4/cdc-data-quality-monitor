"""Reads new rows from change_log, validates them, and records violations.

Run once:        python -m dq_monitor.consumer
Run continuously: python -m dq_monitor.consumer --watch 10
"""
from __future__ import annotations

import argparse
import logging
import os
import time

import psycopg
from psycopg.rows import dict_row

from dq_monitor.rules import evaluate, load_rules

CONSUMER_NAME = "dq_monitor"
BATCH_SIZE = 500
log = logging.getLogger("dq_monitor")


def get_checkpoint(cur) -> int:
    cur.execute("SELECT last_change_id FROM dq_checkpoint WHERE consumer = %s", (CONSUMER_NAME,))
    row = cur.fetchone()
    return row["last_change_id"] if row else 0


def save_checkpoint(cur, change_id: int) -> None:
    cur.execute(
        """INSERT INTO dq_checkpoint (consumer, last_change_id) VALUES (%s, %s)
           ON CONFLICT (consumer) DO UPDATE SET last_change_id = EXCLUDED.last_change_id""",
        (CONSUMER_NAME, change_id),
    )


def process_batch(conn, table_rules: dict) -> tuple[int, int]:
    """Process one batch. Checkpoint and violations commit together, so a crash
    never skips or double-counts changes."""
    with conn.transaction(), conn.cursor(row_factory=dict_row) as cur:
        last_id = get_checkpoint(cur)
        cur.execute(
            """SELECT change_id, table_name, operation, row_data FROM change_log
               WHERE change_id > %s ORDER BY change_id LIMIT %s""",
            (last_id, BATCH_SIZE),
        )
        changes = cur.fetchall()
        if not changes:
            return 0, 0

        found = 0
        for change in changes:
            spec = table_rules.get(change["table_name"])
            if spec is None or change["operation"] == "DELETE":
                continue
            row = change["row_data"]
            for v in evaluate(row, spec["rules"]):
                cur.execute(
                    """INSERT INTO dq_violation
                       (change_id, table_name, record_key, rule_name, severity, message)
                       VALUES (%s, %s, %s, %s, %s, %s)""",
                    (change["change_id"], change["table_name"], str(row.get(spec["key"])),
                     v.rule_name, v.severity, v.message),
                )
                found += 1

        save_checkpoint(cur, changes[-1]["change_id"])
        cur.execute(
            "INSERT INTO dq_run (changes_checked, violations_found) VALUES (%s, %s)",
            (len(changes), found),
        )
        return len(changes), found


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--rules", default="rules.yml")
    parser.add_argument("--watch", type=int, metavar="SECONDS", help="poll interval; omit to run once")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

    table_rules = load_rules(args.rules)
    dsn = os.getenv("DATABASE_URL", "postgresql://dq:dq@localhost:5432/dq")

    with psycopg.connect(dsn) as conn:
        while True:
            checked, found = process_batch(conn, table_rules)
            if checked:
                log.info("checked %d changes, %d violations", checked, found)
            elif not args.watch:
                log.info("no new changes")
            if checked == BATCH_SIZE:
                continue  # more backlog, keep going
            if not args.watch:
                break
            time.sleep(args.watch)


if __name__ == "__main__":
    main()
