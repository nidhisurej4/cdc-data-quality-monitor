"""CDC-driven data quality monitor for PostgreSQL."""
