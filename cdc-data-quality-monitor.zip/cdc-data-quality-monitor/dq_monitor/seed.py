"""Generate sample bookings, including deliberately bad ones, to demo the monitor."""
from __future__ import annotations

import os
import random
from datetime import date, timedelta

import psycopg

PORTS = ["INBLR", "INNSA", "NLRTM", "SGSIN", "DEHAM", "USNYC", "CNSHA"]
STATUSES = ["PENDING", "CONFIRMED", "SHIPPED", "CANCELLED"]


def good_booking() -> dict:
    o, d = random.sample(PORTS, 2)
    return {
        "customer_code": random.choice(["ACME", "GLOBEX", "INITECH", "UMBRELLA"]),
        "origin": o, "destination": d,
        "container_count": random.randint(1, 40),
        "rate_usd": round(random.uniform(800, 4000), 2),
        "ship_date": date.today() + timedelta(days=random.randint(-30, 60)),
        "status": random.choice(STATUSES),
    }


def bad_booking() -> dict:
    b = good_booking()
    corruption = random.choice(["customer", "port", "count", "rate", "status"])
    if corruption == "customer":
        b["customer_code"] = None
    elif corruption == "port":
        b["origin"] = random.choice(["Bangalore", "in-blr", "XX"])
    elif corruption == "count":
        b["container_count"] = random.choice([0, -2, 9999])
    elif corruption == "rate":
        b["rate_usd"] = random.choice([0, -150])
    else:
        b["status"] = random.choice(["shipped", "UNKNOWN"])
    return b


def main(n: int = 200, bad_ratio: float = 0.15) -> None:
    dsn = os.getenv("DATABASE_URL", "postgresql://dq:dq@localhost:5432/dq")
    with psycopg.connect(dsn) as conn, conn.cursor() as cur:
        for _ in range(n):
            b = bad_booking() if random.random() < bad_ratio else good_booking()
            cur.execute(
                """INSERT INTO bookings (customer_code, origin, destination, container_count,
                                         rate_usd, ship_date, status)
                   VALUES (%(customer_code)s, %(origin)s, %(destination)s, %(container_count)s,
                           %(rate_usd)s, %(ship_date)s, %(status)s)""",
                b,
            )
    print(f"Inserted {n} bookings (~{int(n * bad_ratio)} with data issues)")


if __name__ == "__main__":
    main()
