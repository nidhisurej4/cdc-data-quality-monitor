"""Rule engine. Pure functions, no database access, so it is easy to test."""
from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from typing import Any, Callable

import yaml


@dataclass(frozen=True)
class Violation:
    rule_name: str
    severity: str
    message: str


def _to_number(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _to_date(value: Any) -> date | None:
    if isinstance(value, date):
        return value
    if isinstance(value, str):
        try:
            return datetime.fromisoformat(value).date()
        except ValueError:
            return None
    return None


def check_not_null(row: dict, rule: dict) -> str | None:
    value = row.get(rule["column"])
    if value is None or (isinstance(value, str) and not value.strip()):
        return f"{rule['column']} is empty"
    return None


def check_range(row: dict, rule: dict) -> str | None:
    col = rule["column"]
    if row.get(col) is None:
        return None  # nulls are the not_null rule's job
    num = _to_number(row[col])
    if num is None:
        return f"{col}={row[col]!r} is not numeric"
    if "min" in rule and num < rule["min"]:
        return f"{col}={num} is below min {rule['min']}"
    if "max" in rule and num > rule["max"]:
        return f"{col}={num} is above max {rule['max']}"
    return None


def check_allowed_values(row: dict, rule: dict) -> str | None:
    value = row.get(rule["column"])
    if value is not None and value not in rule["values"]:
        return f"{rule['column']}={value!r} not in {rule['values']}"
    return None


def check_regex(row: dict, rule: dict) -> str | None:
    value = row.get(rule["column"])
    if value is not None and not re.fullmatch(rule["pattern"], str(value)):
        return f"{rule['column']}={value!r} does not match {rule['pattern']}"
    return None


def check_date_order(row: dict, rule: dict) -> str | None:
    start, end = _to_date(row.get(rule["start"])), _to_date(row.get(rule["end"]))
    if start and end and end < start:
        return f"{rule['end']} ({end}) is before {rule['start']} ({start})"
    return None


def check_max_age_days(row: dict, rule: dict, today: date | None = None) -> str | None:
    d = _to_date(row.get(rule["column"]))
    today = today or date.today()
    if d and (today - d).days > rule["days"]:
        return f"{rule['column']} ({d}) is older than {rule['days']} days"
    return None


CHECKS: dict[str, Callable[[dict, dict], str | None]] = {
    "not_null": check_not_null,
    "range": check_range,
    "allowed_values": check_allowed_values,
    "regex": check_regex,
    "date_order": check_date_order,
    "max_age_days": check_max_age_days,
}


def evaluate(row: dict, rules: list[dict]) -> list[Violation]:
    """Run every rule against one row and return the violations."""
    violations = []
    for rule in rules:
        check = CHECKS.get(rule["type"])
        if check is None:
            raise ValueError(f"Unknown rule type: {rule['type']}")
        message = check(row, rule)
        if message:
            violations.append(Violation(rule["name"], rule.get("severity", "medium"), message))
    return violations


def load_rules(path: str | Path) -> dict:
    with open(path, encoding="utf-8") as f:
        config = yaml.safe_load(f)
    for table, spec in config["tables"].items():
        for rule in spec["rules"]:
            if rule["type"] not in CHECKS:
                raise ValueError(f"{table}.{rule['name']}: unknown type {rule['type']}")
    return config["tables"]
